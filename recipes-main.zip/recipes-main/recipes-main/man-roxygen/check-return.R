#' @return An updated version of `recipe` with the new check added to the
#'  sequence of any existing operations.
