#' @details
#'
#' This step can potentially remove columns from the data set. This may
#'  cause issues for subsequent steps in your recipe if the missing columns are
#'  specifically referenced by name. To avoid this, see the advice in the
#'  _Tips for saving recipes and filtering columns_ section of [selections].
