#' @return An updated version of `recipe` with the new step added to the
#'  sequence of any existing operations.
